package database;

import java.util.ArrayList;
import java.util.List;

import model.Room;
import model.Equipment;
import model.EnergyReading;

public class DatabaseManager {

    private List<Room> rooms;

    public DatabaseManager() {
        rooms = generateRooms();
    }
 

    public List<Room> getAllRooms() {
        return rooms;
    }

    private List<Room> generateRooms() {
        List<Room> rooms = new ArrayList<>();
        
        //Room 406
        List<Equipment> room406 = new ArrayList<>();
        room406.add(new Equipment(1, "Slide", 50));
        room406.add(new Equipment(2, "Ductless AC", 1500));
        room406.add(new Equipment(3, "Cassette AC", 2000));
        room406.add(new Equipment(4, "Lights", 100));

        rooms.add(new Room(1, "406", room406.size(), room406));
        
        //Room 201
        List<Equipment> room201 = new ArrayList<>();
        room201.add(new Equipment(5, "Slide", 50));
        room201.add(new Equipment(6, "Ductless AC", 1500));
        room201.add(new Equipment(7, "Ductless AC", 1500));
        room201.add(new Equipment(8, "Cassette AC", 2000));
        room201.add(new Equipment(9, "Cassette AC", 2000));
        room201.add(new Equipment(10, "Lights", 100));

        rooms.add(new Room(2, "201", room201.size(), room201));

        return rooms;

    }

    public List<EnergyReading> getAllReadings() {
        return generateReadings();
    }

    private List<EnergyReading> generateReadings() {

        List<EnergyReading> readings = new ArrayList<>();
        
        
        readings.add(new EnergyReading(rooms.get(0), "08:30", 22));
        readings.add(new EnergyReading(rooms.get(0), "10:00", 28));
        readings.add(new EnergyReading(rooms.get(0), "11:30", 24));

        
        readings.add(new EnergyReading(rooms.get(1), "13:30", 30));
        readings.add(new EnergyReading(rooms.get(1), "15:00", 35));
        readings.add(new EnergyReading(rooms.get(1), "16:30", 32));

        return readings;
    }

}
